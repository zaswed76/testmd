test script for testing
utilities setuptools